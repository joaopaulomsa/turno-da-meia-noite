# Instruções do projeto

Quando o pedido envolver criar, adaptar ou integrar uma história Ren'Py, carregue e siga:

- `.github/agents/especialista-historias-renpy.agent.md`
- `.github/skills/renpy-story-pipeline/SKILL.md`
- `.github/skills/renpy-story-pipeline/references/fluxo-claude-historia2.md` quando a tarefa envolver gerar arte no ChatGPT pela estação do Jarvis.

Para manutenção geral de Ren'Py, consulte `.github/agents/especialista ren'py.agent.md`. Não carregue esses materiais para tarefas sem relação com histórias ou Ren'Py.
