@echo off
setlocal

set "RENPY=C:\renpy\renpy-8.5.2-sdk\renpy.exe"
set "PROJETO=%~dp0."

if not exist "%RENPY%" (
    echo Ren'Py nao encontrado em:
    echo %RENPY%
    echo.
    pause
    exit /b 1
)

"%RENPY%" "%PROJETO%"
