# ============================================================
#  testcases.rpy — Testes de fluxo
#  Execucao: renpy.exe <projeto> test <nome_do_testcase>
# ============================================================
#  Nao afetam o jogo publicado: so rodam sob o comando "test".
#
#  Notas sobre o framework (Ren'Py 8.5):
#   - "click" so acerta displayables focaveis (botoes). Para
#     avancar dialogo use "advance".
#   - "assert label X" nao funciona em execucao normal: o hook
#     add_reached_label so e registrado em on_reload, entao
#     reached_labels fica sempre vazio.
# ============================================================

testsuite global:
    teardown:
        exit


# Menu principal -> selecao de historia -> Historia 1 ate o fim.
testcase selecao_historia1:
    $ _test.transition_timeout = 0.05
    $ _test.timeout = 15.0

    click "Novo Jogo"
    pause 0.4

    click "Personagem A & B"
    pause 0.6

    # O botao da tela de selecao roteou para a historia certa.
    assert eval (historia_escolhida == "chapter1_start")

    # O registro de historias e reconstruido do script, nunca
    # restaurado de um save.
    assert eval (len(historias_disponiveis()) >= 1)

    # Avanca o dialogo ate o menu de escolha aparecer. Contar
    # "advance" seria fragil: o clique no botao da selecao ja
    # consome a primeira fala.
    advance until eval (renpy.get_screen("choice") is not None)

    click "Dar um passo à frente"
    pause 0.3

    # Ramo "aproximar" ate fim_demo, que faz "return" e devolve
    # o jogador ao menu principal.
    advance until eval (renpy.get_screen("main_menu") is not None)


# O ramo alternativo do capitulo 1.
testcase historia1_ramo_recuar:
    $ _test.transition_timeout = 0.05
    $ _test.timeout = 15.0

    click "Novo Jogo"
    pause 0.4
    click "Personagem A & B"
    pause 0.6

    advance until eval (renpy.get_screen("choice") is not None)

    click "Recuar devagar"
    pause 0.3

    advance until eval (renpy.get_screen("main_menu") is not None)


# A tela de selecao deve voltar ao menu principal sem iniciar nada.
testcase selecao_voltar:
    $ _test.transition_timeout = 0.05
    $ _test.timeout = 15.0

    click "Novo Jogo"
    pause 0.4
    click "Voltar"
    pause 0.5

    # De volta ao menu principal, sem ter iniciado historia alguma.
    assert eval (renpy.get_screen("main_menu") is not None)
    assert eval (historia_escolhida is None)


# TEMPORARIO — captura de tela para inspecao visual.
testcase captura_telas:
    $ _test.transition_timeout = 0.05
    $ _test.timeout = 20.0
    $ _test.overwrite_screenshots = True

    pause 0.8
    screenshot "01_menu_principal"

    click "Novo Jogo"
    pause 0.8
    screenshot "02_selecao_historia"

    click "Personagem A & B"
    pause 1.0
    screenshot "03_primeira_fala"


# ============================================================
#  Historia 2 — "Sinal Fraco"
# ============================================================
#  Os 3 caminhos possiveis pelo h2_desconfianca, cada um passando
#  pelos 4 cenarios (estrada, capela, casa, porao).

# Todas as escolhas calmas: desconfianca fica em 0, cai direto em
# h2_fim_registro sem passar por h2_escolha_final.
testcase historia2_final_registro_direto:
    $ _test.transition_timeout = 0.05
    $ _test.timeout = 25.0

    click "Novo Jogo"
    pause 0.4
    click "Sinal Fraco"
    pause 0.6

    assert eval (historia_escolhida == "h2_start")

    advance until eval (renpy.get_screen("choice") is not None)
    click "Seguir a pé"                        # cenario 1 -> 2, sem escolha extra

    advance until eval (renpy.get_screen("choice") is not None)
    click "Deixar o caderno"

    advance until eval (renpy.get_screen("choice") is not None)
    click "Não perguntar nada"

    advance until eval (renpy.get_screen("choice") is not None)
    click "Aceitar e ir com ele"               # cenario 2 -> 3

    advance until eval (renpy.get_screen("choice") is not None)
    click "Fingir que não viu"

    advance until eval (renpy.get_screen("choice") is not None)
    assert eval (h2_desconfianca == 0 and not h2_leu_caderno)
    click "Descer com ele"                     # cenario 3 -> 4, direto ao telefone

    # O "return" de h2_fim_registro reinicia o jogo (sem "call" para
    # retornar), o que reseta os "default" — por isso so verificamos
    # o estado ANTES deste ponto, nao depois.
    advance until eval (renpy.get_screen("main_menu") is not None)


# Mistura: desconfianca fica em 2, passa por h2_escolha_final e
# responde ao telefone -> tambem termina em h2_fim_registro.
testcase historia2_escolha_final_responder:
    $ _test.transition_timeout = 0.05
    $ _test.timeout = 25.0

    click "Novo Jogo"
    pause 0.4
    click "Sinal Fraco"
    pause 0.6

    advance until eval (renpy.get_screen("choice") is not None)
    click "Seguir a pé"

    advance until eval (renpy.get_screen("choice") is not None)
    click "Deixar o caderno"

    advance until eval (renpy.get_screen("choice") is not None)
    click "Como assim"                         # +2 desconfianca

    advance until eval (renpy.get_screen("choice") is not None)
    click "Aceitar e ir com ele"

    advance until eval (renpy.get_screen("choice") is not None)
    click "Fingir que não viu"

    advance until eval (renpy.get_screen("choice") is not None)
    click "Descer com ele"

    # desconfianca == 2: cai em h2_escolha_final (2 <= x < 4).
    advance until eval (renpy.get_screen("choice") is not None)
    assert eval (h2_desconfianca == 2)
    click "Responder"

    advance until eval (renpy.get_screen("main_menu") is not None)


# Todas as escolhas suspeitas: desconfianca passa de 4, cai direto
# em h2_fim_fuga sem passar por h2_escolha_final.
testcase historia2_final_fuga_direto:
    $ _test.transition_timeout = 0.05
    $ _test.timeout = 25.0

    click "Novo Jogo"
    pause 0.4
    click "Sinal Fraco"
    pause 0.6

    advance until eval (renpy.get_screen("choice") is not None)
    click "Trancar as portas"                  # +1

    advance until eval (renpy.get_screen("choice") is not None)
    assert eval (h2_desconfianca == 1)
    click "Ler o caderno"                      # +1

    advance until eval (renpy.get_screen("choice") is not None)
    assert eval (h2_desconfianca == 2 and h2_leu_caderno)
    click "Como assim"                         # +2 (total 4 antes da casa)

    advance until eval (renpy.get_screen("choice") is not None)
    assert eval (h2_desconfianca == 4)
    click "Recusar e voltar"                   # +2 (total 6)

    # 4 + 2 ("Recusar e voltar") + 1 (bonus automatico por ter lido
    # o caderno, aplicado em h2_cen_casa antes deste menu aparecer).
    advance until eval (renpy.get_screen("choice") is not None)
    assert eval (h2_desconfianca == 7)
    click "Perguntar sobre as fotos"           # +2

    advance until eval (renpy.get_screen("choice") is not None)
    assert eval (h2_desconfianca == 9)
    # desconfianca >= 4: "Descer com ele" leva direto a h2_fim_fuga,
    # sem passar por h2_escolha_final (sem menu no porao).
    click "Descer com ele"

    # O "return" de h2_fim_fuga nao tem "call" para retornar: e um
    # reinicio do jogo (igual ao fim_demo da historia 1), que reseta
    # todos os "default" — inclusive h2_desconfianca. Por isso o
    # unico estado verificavel apos chegar ao menu e que chegamos
    # ao menu principal normalmente, sem crash.
    advance until eval (renpy.get_screen("main_menu") is not None)


# TEMPORARIO — captura de tela para verificar ajustes da historia 3.
testcase h3_captura_ajustes:
    $ _test.transition_timeout = 0.05
    $ _test.timeout = 25.0
    $ _test.overwrite_screenshots = True

    click "Novo Jogo"
    pause 0.4
    click "O Caso do Herdeiro"

    advance until eval (renpy.get_screen("say") is not None)
    pause 0.5
    screenshot "h3_00_logo_apos_entrar"

    advance   # "Ok... Cena do crime..."
    advance   # narrador 1
    advance   # narrador 2
    advance until eval (renpy.get_screen("choice") is not None)
    pause 0.3
    screenshot "h3_01_detetive_invertido_e_subido"

    click "Observar a arma do crime"
    advance until eval (renpy.get_screen("say") is not None)
    pause 0.3
    screenshot "h3_02_faca_centralizada_sem_personagem"

    advance until eval (renpy.get_screen("choice") is not None)
    click "A — A vizinha"
    pause 0.2

    advance   # dispensa "A arma não me deu informação..."
    pause 0.2
    advance   # dispensa "Sem uma pista útil..." -> troca de bg, mostra a fala final
    pause 0.3
    screenshot "h3_03_final_errado_com_frase"       # bg ja deve ser imagem_2

    advance until eval (renpy.get_screen("main_menu") is not None)


# TEMPORARIO — captura de tela para verificar reskin vermelho do nucleo.
testcase nucleo_captura_vermelho:
    $ _test.transition_timeout = 0.05
    $ _test.timeout = 20.0
    $ _test.overwrite_screenshots = True

    pause 0.6
    screenshot "nucleo_01_menu_principal"

    click "Configurações"
    pause 0.6
    screenshot "nucleo_02_preferencias"

    click "Voltar"
    pause 0.4

    click "Carregar"
    pause 0.6
    screenshot "nucleo_03_carregar"
