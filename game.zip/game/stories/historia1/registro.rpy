# ============================================================
#  Historia 1 — Registro na tela de selecao
# ============================================================

init -40 python:
    registrar_historia(
        id="historia1",
        titulo="Personagem A & B",
        subtitulo="Demonstração — 1 capítulo, 2 finais",
        label="chapter1_start",
        ordem=10,
    )
