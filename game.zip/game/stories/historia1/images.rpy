# ============================================================
#  Historia 1 — Imagens
# ============================================================
#  Caminhos sao relativos a game/, independente de onde este
#  arquivo esteja. Os assets continuam em game/images/.
#
#  ATENCAO: estes nomes de imagem constam nos saves existentes.
# ============================================================

image personagem_a = "images/personagem_a.png"
image personagem_b = "images/personagem_b.png"
image bg_quarto = Transform("images/bg_quarto_wide.png", xysize=(1280, 720), fit="cover")
image bg_sala = Transform("images/bg_quarto_wide.png", xysize=(1280, 720), fit="cover")
