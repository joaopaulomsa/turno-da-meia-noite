# ============================================================
#  Historia 1 — Narrativa
# ============================================================
#  Personagens: chars.rpy   |   Imagens: images.rpy
#  Infraestrutura (label start, menus): game/core/boot.rpy
#
#  ATENCAO: os nomes de label abaixo constam nos saves
#  existentes. Nao renomear sem aceitar a quebra.
# ============================================================

label chapter1_start:

    scene bg_quarto

    $ first_story_dialogue = True
    n "Era uma tarde comum quando tudo mudou..."
    $ first_story_dialogue = False

    show personagem_a at left
    p "Oi. Você... você me vê, né?"

    show personagem_b at right
    b "Claro que vejo. Eu sempre te vejo."

    p "Isso me assusta um pouco."
    b "Só um pouco?"

    n "Havia algo diferente no olhar dele. Algo que ela não conseguia nomear."

    menu:
        "Dar um passo à frente":
            jump aproximar

        "Recuar devagar":
            jump recuar


# --- Ramos ---
label aproximar:
    p "Eu... preciso saber quem você é."
    b "Isso vai levar tempo. Você tem tempo?"
    p "Tenho."
    jump fim_demo

label recuar:
    p "Me dê espaço."
    b "Tudo bem. Estarei aqui quando você quiser."
    n "Ela se afastou. Mas não conseguia parar de pensar nele."
    jump fim_demo

label fim_demo:
    n "— Fim da demonstração —"
    n "Obrigado por jogar! Mais capítulos em breve."
    return
