# ============================================================
#  Historia 1 — Personagens
# ============================================================
#  ATENCAO: estes nomes (p, b, n) constam nos saves existentes.
#  Nao renomear sem aceitar a quebra de compatibilidade.
# ============================================================

define p = Character("Personagem A", color="#e8a0bf")
define b = Character("Personagem B", color="#a0c4e8")
define n = Character(None)  # Narrador (sem nome)
