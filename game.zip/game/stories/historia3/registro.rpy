# ============================================================
# Historia 3 — Registro na tela de selecao
# ============================================================

init -40 python:
    registrar_historia(
        id="historia3",
        titulo="O Caso do Herdeiro",
        subtitulo="Misterio — uma cena, duas pistas",
        label="h3_start",
        ordem=30,
    )
