# Assets fornecidos pelo usuario; caminhos relativos a game/.

## ---- Tema visual "vampiro" (vermelho e preto, detalhes suaves) ----
## TintMatrix mistura a imagem original em direcao a cor indicada; o
## canal alfa do hexadecimal (ultimo par) e a forca da mistura. Valores
## baixos (perto de 0x20-0x30 de 0xFF) mantem o material original
## reconhecivel, so deslocando a paleta — por isso "suave".
define h3_grade_fundo = SaturationMatrix(0.78) * TintMatrix("#1b05062e")
define h3_grade_sprite = SaturationMatrix(0.92) * TintMatrix("#2a08082a")

# Vinheta: preto com leve matiz vermelho-sangue, transparente no
# centro e mais presente nos cantos. Gerada em images/vinheta_vampiro.png.
image h3_vinheta = "stories/historia3/images/vinheta_vampiro.png"

image h3_bg_quarto = Composite(
    (1280, 720),
    (0, 0), Transform(
        "stories/historia3/images/WhatsApp Image 2026-10-07 at 20.42.43.jpeg",
        xysize=(1280, 720), fit="cover", matrixcolor=h3_grade_fundo,
    ),
    (0, 0), "stories/historia3/images/vinheta_vampiro.png",
)

# Pistas e desfechos da investigacao.
image h3_bg_pegadas = Composite(
    (1280, 720),
    (0, 0), Transform(
        "stories/historia3/images/imagem_1_1280x720.jpg",
        xysize=(1280, 720), fit="cover", matrixcolor=h3_grade_fundo,
    ),
    (0, 0), "stories/historia3/images/vinheta_vampiro.png",
)

image h3_bg_final_posto = Composite(
    (1280, 720),
    (0, 0), Transform(
        "stories/historia3/images/imagem_2_1280x720.jpg",
        xysize=(1280, 720), fit="cover", matrixcolor=h3_grade_fundo,
    ),
    (0, 0), "stories/historia3/images/vinheta_vampiro.png",
)

image h3_bg_final_prisao = Composite(
    (1280, 720),
    (0, 0), Transform(
        "stories/historia3/images/imagem_3_1280x720.jpg",
        xysize=(1280, 720), fit="cover", matrixcolor=h3_grade_fundo,
    ),
    (0, 0), "stories/historia3/images/vinheta_vampiro.png",
)

# Recorte PNG com transparencia; o JPEG original da faca foi preservado.
image h3_faca = Transform(
    "stories/historia3/images/faca_transparente.png",
    zoom=0.42,
    matrixcolor=h3_grade_sprite,
)

# Retrato recortado com transparencia; o JPEG original foi preservado.
# xzoom negativo espelha o personagem horizontalmente (mesma escala
# do yzoom, só invertida); yoffset negativo sobe o personagem um
# pouco em relacao ao chao da cena.
image h3_detetive = Transform(
    "stories/historia3/images/detetive.png",
    xzoom=-0.34,
    yzoom=0.34,
    yoffset=-40,
    matrixcolor=h3_grade_sprite,
)
