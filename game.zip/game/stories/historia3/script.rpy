# ============================================================
# Historia 3 — O Caso do Herdeiro
# Mini misterio de observacao: escolher uma pista e identificar o culpado.
# ============================================================

default h3_viu_pegadas = False


label h3_start:

    scene h3_bg_quarto with fade
    show h3_detetive at left with dissolve

    $ h3_viu_pegadas = False
    $ first_story_dialogue = True
    h3_det "Ok... Cena do crime. Temos dois suspeitos: o melhor amigo da vítima e a vizinha. Ambos tinham suas razões para o querer morto... Vamos ver o que posso encontrar."
    $ first_story_dialogue = False

    h3_n "O herdeiro foi encontrado morto neste escritório. Perto dele há uma arma, e a porta para o lado de fora está entreaberta."
    h3_n "O relatório lista dois suspeitos: A, a vizinha; e B, o amigo."
    h3_det "A cena oferece duas pistas. Preciso escolher onde olhar."

    menu:
        "Observar a arma do crime":
            jump h3_investigar_arma

        "Observar a porta":
            jump h3_investigar_porta


label h3_investigar_arma:

    # A faca aparece sozinha, centralizada, sem o detetive na cena.
    hide h3_detetive with dissolve
    show h3_faca at truecenter with dissolve
    h3_det "Arma usada para matar Moonveil."
    h3_det "Não me dá nenhuma pista."
    hide h3_faca with dissolve
    show h3_detetive at left with dissolve
    jump h3_escolher_assassino


label h3_investigar_porta:

    $ h3_viu_pegadas = True
    scene h3_bg_pegadas with dissolve
    show h3_detetive at left with dissolve
    h3_det "Pegadas."
    h3_det "Parecem grandes demais para serem femininas."
    h3_n "A vizinha A é mulher. O amigo B é homem."
    scene h3_bg_quarto with dissolve
    show h3_detetive at left with dissolve
    jump h3_escolher_assassino


label h3_escolher_assassino:

    h3_det "Quem é o assassino?"

    menu:
        "A — A vizinha":
            jump h3_acusar_a

        "B — O amigo":
            jump h3_acusar_b


label h3_acusar_a:

    if h3_viu_pegadas:
        h3_det "As pegadas parecem grandes demais para serem femininas. A vizinha não corresponde à pista."
        h3_n "Você tinha a pista, mas escolheu a suspeita errada."
    else:
        h3_det "A arma não me deu informação para escolher. Ainda assim, acusei a vizinha."
        h3_n "Sem uma pista útil, a acusação foi apenas um palpite — e não foi o certo."

    # O background muda primeiro: a frase final aparece junto com ele.
    # Depois dela, a caixa de texto e apagada (sem a linha "— Fim —"),
    # deixando a tela final limpa por um instante antes de voltar.
    scene h3_bg_final_posto with fade
    h3_n "Resposta errada. O assassino é B, o amigo, e continua à solta."
    window hide
    pause 2.0
    return


label h3_acusar_b:

    if h3_viu_pegadas:
        h3_det "A vizinha é mulher. O amigo é homem. As pegadas apontam para B."
        h3_n "Resposta correta. B, o amigo, é o assassino."
    else:
        h3_det "A arma não indicava quem era o culpado. Mesmo assim, escolhi o amigo B."
        h3_n "Resposta correta. B, o amigo, é o assassino. Você acertou sem uma pista que sustentasse a escolha."

    # Mesma logica do final errado: a frase final acompanha o
    # background, depois a caixa de texto e apagada antes de voltar.
    scene h3_bg_final_prisao with fade
    h3_n "O amigo B foi capturado. Caso encerrado."
    window hide
    pause 2.0
    return
