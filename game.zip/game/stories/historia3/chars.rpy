# ============================================================
#  Historia 3 — "O Caso do Herdeiro" — Personagens
# ============================================================
#  Todos os nomes levam o prefixo h3_ para nao colidirem com as
#  historias 1 e 2.
# ============================================================

define h3_det = Character("Alaric", color="#b0141f")
define h3_n = Character(None)   # Narrador
