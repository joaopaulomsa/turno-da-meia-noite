# ============================================================
#  Historia 2 — "Sinal Fraco" — Personagens
# ============================================================
#  Todos os nomes levam o prefixo h2_ para nao colidirem com a
#  historia 1 (que usa p, b, n sem prefixo e cujos nomes estao
#  congelados por causa dos saves antigos).
# ============================================================

define h2_hel = Character("Helena", color="#9ec5d8")
define h2_ama = Character("Sr. Amaro", color="#c2a06a")
define h2_voz = Character("???", color="#8a6a8a")
define h2_n = Character(None)   # Narrador
