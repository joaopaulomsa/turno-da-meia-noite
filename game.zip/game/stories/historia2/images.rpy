# ============================================================
#  Historia 2 — "Sinal Fraco" — Imagens
# ============================================================
#  Caminhos relativos a game/. Os assets desta historia ficam
#  na propria pasta dela, nao em game/images/.
# ============================================================

# --- Os 4 cenarios ---
image h2_bg_estrada = Transform("stories/historia2/images/bg_estrada.png", xysize=(1280, 720), fit="cover")
image h2_bg_capela  = Transform("stories/historia2/images/bg_capela.png",  xysize=(1280, 720), fit="cover")
image h2_bg_casa    = Transform("stories/historia2/images/bg_casa.png",    xysize=(1280, 720), fit="cover")
image h2_bg_porao   = Transform("stories/historia2/images/bg_porao.png",   xysize=(1280, 720), fit="cover")

# --- Personagens ---
# Os sprites originais têm 1672 px de altura; reduzi-los para caber
# proporcionalmente na resolução de jogo (1280x720).
image h2_helena = Transform("stories/historia2/images/helena.png", zoom=0.40)
image h2_amaro  = Transform("stories/historia2/images/amaro.png",  zoom=0.40)
