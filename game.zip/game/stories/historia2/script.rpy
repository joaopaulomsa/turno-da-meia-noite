# ============================================================
#  Historia 2 — "Sinal Fraco"
# ============================================================
#  Terror psicologico. 4 cenarios, 2 finais.
#
#   1. h2_bg_estrada — a estrada, de madrugada
#   2. h2_bg_capela  — a capela a beira da pista
#   3. h2_bg_casa    — a casa do zelador
#   4. h2_bg_porao   — o porao
#
#  Personagens: chars.rpy   |   Imagens: images.rpy
#  Todos os nomes levam prefixo h2_ para nao colidirem com a
#  historia 1, cujos nomes estao congelados por causa dos saves.
# ============================================================

# Quanto Helena desconfia do Sr. Amaro. Sobe quando ela presta
# atencao no que nao fecha. Decide o final no porao.
default h2_desconfianca = 0

# Ela chegou a ler o caderno da capela.
default h2_leu_caderno = False


# ============================================================
#  Cenario 1 — A estrada
# ============================================================
label h2_start:

    scene h2_bg_estrada with fade

    $ first_story_dialogue = True
    h2_n "O motor morreu às 23h40, no km 62, sem nem tossir antes."
    $ first_story_dialogue = False

    h2_n "Helena ficou um tempo parada, com as mãos ainda no volante, esperando o carro voltar sozinho — como se máquinas fizessem esse tipo de favor."

    show h2_helena at right with dissolve

    h2_hel "Tudo bem. Tudo bem."
    h2_hel "Uma barra de sinal. Só preciso de uma."

    h2_n "O celular marcava 7%%. Nenhuma barra. Ela ergueu o aparelho acima da cabeça, girou devagar, e o número não mudou."

    h2_n "A neblina não era densa. Era pior: fina o bastante para deixar ver uns trinta metros de asfalto molhado, e nada além disso."

    h2_n "Foi então que ela percebeu a luz. Fraca, amarelada, firme. Uns oitocentos metros adiante, fora da pista."

    menu:
        "Seguir a pé até a luz":
            h2_hel "Melhor do que ficar aqui."
            jump h2_cen_capela

        "Trancar as portas e esperar o amanhecer":
            jump h2_esperar_no_carro


label h2_esperar_no_carro:

    h2_hel "Alguém vai passar. Sempre passa alguém."

    h2_n "Ninguém passou."

    h2_n "Às 00h20, o rádio do carro ligou sozinho. Chiado. Só chiado — o mesmo chiado por quatro minutos inteiros, no volume em que ela nunca deixava."

    h2_n "Quando ela estendeu a mão para desligar, o chiado parou antes de ela encostar no botão."

    h2_hel "..."

    h2_n "Ela saiu do carro. Não por coragem. Por não aguentar ficar dentro dele."

    # A desconfianca nasce aqui: ela ja viu que o lugar e errado.
    $ h2_desconfianca += 1

    jump h2_cen_capela


# ============================================================
#  Cenario 2 — A capela
# ============================================================
label h2_cen_capela:

    scene h2_bg_capela with fade

    h2_n "A luz não vinha de uma casa. Vinha de uma capela — dessas pequenas, de beira de estrada, erguidas por promessa de alguém que escapou de alguma coisa."

    h2_n "A porta estava encostada. Dentro, uma lâmpada nua pendurada no fio, acesa."

    show h2_helena at left with dissolve

    h2_hel "Tem energia aqui. Então tem gente."

    h2_n "Havia seis bancos. No terceiro, um caderno de capa dura, aberto, com uma caneta atravessada nas páginas."

    menu:
        "Ler o caderno":
            $ h2_leu_caderno = True
            $ h2_desconfianca += 1

            h2_n "Eram nomes. Duas colunas: nome e data. A caligrafia era a mesma em todas as linhas, do começo ao fim — o que era estranho, porque as datas iam de 1994 até aquela semana."

            h2_n "A última linha estava preenchida pela metade:"

            h2_voz "Helena M. —"

            h2_hel "Não."
            h2_hel "Não, isso é... alguém está brincando."

            h2_n "A tinta ainda estava úmida."

        "Deixar o caderno onde está":
            h2_n "Ela leu o suficiente para ver que eram nomes, e fechou o caderno antes de chegar no próprio."
            h2_hel "Não é da minha conta."

    show h2_amaro at right with dissolve

    h2_ama "A senhora se perdeu?"

    h2_n "Helena não ouviu a porta. Não ouviu passo nenhum. O homem simplesmente estava ali, de pé no corredor entre os bancos, com uma lanterna apagada na mão."

    h2_hel "Meu carro quebrou. No km 62."

    h2_ama "Km 62."
    h2_ama "É sempre no 62."

    menu:
        "\"Como assim, sempre?\"":
            $ h2_desconfianca += 2
            h2_ama "Força de expressão, moça."
            h2_n "Ele sorriu. O sorriso chegou tarde demais, como legenda fora de sincronia."

        "Não perguntar nada":
            h2_n "Helena guardou a pergunta. Guardou também o jeito como ele disse aquilo: sem surpresa nenhuma."

    h2_ama "Tenho telefone fixo lá em casa. Linha velha, mas pega."
    h2_ama "São dez minutos a pé. Com essa chuva, oito."

    h2_n "Não estava chovendo."

    menu:
        "Aceitar e ir com ele":
            jump h2_cen_casa

        "Recusar e voltar para o carro":
            h2_hel "Obrigada, mas eu prefiro esperar na estrada."

            h2_ama "Prefere."

            h2_n "Ele não insistiu. Deu as costas e foi apagando a lâmpada da capela, como quem fecha o expediente."

            h2_n "Helena andou de volta pelo acostamento por quarenta minutos. Oitocentos metros levam oito."

            h2_n "No fim dos quarenta minutos, ela chegou à capela."

            $ h2_desconfianca += 2
            h2_hel "..."

            h2_ama "Como eu disse. Dez minutos a pé."

            jump h2_cen_casa


# ============================================================
#  Cenario 3 — A casa
# ============================================================
label h2_cen_casa:

    scene h2_bg_casa with fade

    h2_n "A casa era de fazenda, baixa, com um lampião a óleo na mesa da sala e luz elétrica em lugar nenhum."

    show h2_amaro at right with dissolve

    h2_hel "O senhor disse que tinha telefone."

    h2_ama "Tenho. No porão."

    h2_hel "No porão."

    h2_ama "A linha entra por baixo. Coisa antiga."

    h2_n "Na parede da sala havia fotografias. Muitas. Emolduradas com capricho, alinhadas com régua."

    h2_n "Em todas elas, o mesmo homem — o Sr. Amaro — ao lado de uma pessoa diferente. Sempre na frente da capela. Sempre à noite."

    h2_n "E em todas, ele tinha exatamente a idade que tinha agora."

    if h2_leu_caderno:
        $ h2_desconfianca += 1
        h2_n "Helena contou as molduras sem querer. Deu o mesmo número de linhas que havia no caderno."

    menu:
        "Perguntar sobre as fotos":
            $ h2_desconfianca += 2
            h2_hel "Quem são essas pessoas?"

            h2_ama "Gente que o carro deixou na mão."

            h2_ama "Eu ajudo, elas agradecem, a gente tira o retrato. É de educação."

            h2_hel "E depois?"

            h2_ama "Depois elas vão embora, ué."
            h2_n "Ele disse isso olhando para o chão do corredor. Para a porta no fim dele."

        "Fingir que não viu":
            h2_n "Helena desviou os olhos das molduras com a naturalidade que conseguiu, que não foi muita."
            h2_ama "Pode olhar à vontade. Todo mundo olha."

    h2_ama "O telefone, então?"

    h2_n "Ele abriu a porta no fim do corredor. Degraus de madeira desciam para o escuro, e o cheiro que subiu era de terra molhada — não de casa, de terreno."

    menu:
        "Descer com ele":
            jump h2_cen_porao

        "Pedir para ele descer sozinho e trazer o telefone":
            $ h2_desconfianca += 1
            h2_hel "O senhor não pode trazer o aparelho aqui pra cima?"

            h2_ama "Não."
            h2_ama "O fio é curto."

            h2_n "Ele esperou. Não com impaciência: com paciência demais, do jeito de quem já sabe quanto tempo a pessoa leva para decidir."

            jump h2_cen_porao


# ============================================================
#  Cenario 4 — O porao
# ============================================================
label h2_cen_porao:

    scene h2_bg_porao with fade

    h2_n "O porão era maior que a casa."

    h2_n "Isso não é força de expressão. As paredes iam além de onde a sala terminava lá em cima, e o teto era alto demais para caber embaixo de um piso."

    h2_n "Contra a parede do fundo, uma mesinha. Sobre a mesinha, um telefone preto, de disco, com o fio descendo para dentro do chão de terra."

    show h2_amaro at left with dissolve

    h2_ama "Tá aí. Pode ligar pra quem quiser."

    h2_n "Helena levantou o fone. Havia linha. Uma linha limpa, perfeita, sem chiado nenhum — melhor do que qualquer linha que ela já tinha ouvido."

    h2_n "E, do outro lado, antes de ela discar, alguém respirava."

    if h2_desconfianca >= 4:
        h2_n "Ela não discou."
        h2_n "Tinha reparado em coisa demais na última hora para fingir que aquilo era um favor."
        jump h2_fim_fuga

    elif h2_desconfianca >= 2:
        jump h2_escolha_final

    else:
        h2_n "Helena discou o número de casa sem pensar duas vezes. Estava cansada, e cansaço é a porta que fica aberta."
        jump h2_fim_registro


label h2_escolha_final:

    h2_voz "Alô?"

    h2_n "Era a voz dela. A própria voz de Helena, do outro lado da linha, com o cansaço de quem atende tarde da noite."

    h2_hel "..."

    menu:
        "Desligar e correr para a escada":
            jump h2_fim_fuga

        "Responder":
            jump h2_fim_registro


# ============================================================
#  Finais
# ============================================================
label h2_fim_fuga:

    h2_n "Ela largou o fone pendurado e subiu os degraus de dois em dois."

    h2_n "O Sr. Amaro não correu atrás. Homens que não têm pressa nunca correm."

    h2_ama "Ô moça."
    h2_ama "A estrada é longa."

    scene h2_bg_estrada with fade

    h2_n "Helena andou pelo acostamento até o sol nascer. Quatro horas e meia. O carro estava onde ela tinha deixado, no km 62, e pegou na primeira tentativa."

    h2_n "Ela nunca mais passou por aquela rodovia."

    h2_n "Mas às vezes, tarde da noite, o telefone de casa toca uma vez só — e quando ela atende, há uma linha limpa, perfeita, sem chiado nenhum."

    h2_n "— Fim: Sinal Fraco —"

    return


label h2_fim_registro:

    h2_hel "Alô?"

    h2_n "Do outro lado, a voz dela respondeu junto, na mesma sílaba, com o mesmo cansaço."

    h2_n "O Sr. Amaro tirou o caderno do bolso do casaco e completou a linha que faltava."

    h2_ama "Pronto."
    h2_ama "Agora a senhora pode esperar aqui."

    scene h2_bg_capela with fade

    h2_n "A capela à beira da estrada continua com a luz acesa. É uma luz fraca, amarelada, firme — dá pra ver de uns oitocentos metros, quando o carro morre no km 62."

    h2_n "E tem sempre alguém lá dentro para receber."

    h2_n "— Fim: O Registro —"

    return
