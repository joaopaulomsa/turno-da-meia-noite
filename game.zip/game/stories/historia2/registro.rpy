# ============================================================
#  Historia 2 — Registro na tela de selecao
# ============================================================

init -40 python:
    registrar_historia(
        id="historia2",
        titulo="Sinal Fraco",
        subtitulo="Terror — 4 cenários, 2 finais",
        label="h2_start",
        ordem=20,
    )
