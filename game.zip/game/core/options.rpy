## ============================================================
##  options.rpy — Configurações gerais do projeto
## ============================================================

define config.name = "Turno da Meia-Noite"
define config.version = "0.1"
define build.name = "TurnoDaMeiaNoite"

define config.window_title = "Turno da Meia-Noite"
define config.screen_width = 1280
define config.screen_height = 720

define config.has_sound = True
define config.has_music = True
define config.has_voice = False
define config.auto_load = None

define config.save_directory = "VisualNovel-1"
define config.thumbnail_width = 384
define config.thumbnail_height = 216

define config.default_music_volume = 0.8
define config.default_sfx_volume = 1.0
define config.history_length = 250

init python:
    def _write_history_debug(message):
        import os
        path = os.path.join(config.gamedir, "history_debug.txt")
        with open(path, "a", encoding="utf-8") as debug_file:
            debug_file.write(message + "\n")

    def _debug_native_history_entry(entry):
        _write_history_debug(
            "HISTORY_DEBUG add who={!r} what={!r} enabled={!r}".format(
                entry.who, entry.what, _history
            )
        )

    config.history_callbacks.append(_debug_native_history_entry)

    # Mantem Esc/clique direito sempre abrindo o game_menu.
    km = list(config.keymap.get("game_menu", []))
    for key in ["K_ESCAPE", "mouseup_3", "K_MENU"]:
        if key not in km:
            km.append(key)
    config.keymap["game_menu"] = km
