# ============================================================
#  stories.rpy — Registro de historias (nucleo)
# ============================================================
#  Cada historia se registra a partir da propria pasta, em
#  game/stories/<historia>/registro.rpy. Para adicionar uma
#  historia nova basta criar a pasta com o seu registro.rpy:
#  nenhum arquivo do nucleo precisa ser editado.
#
#  Por que uma variavel de init e nao "default", nem config:
#
#   - "config.historias" NAO funciona: o objeto config rejeita
#     atributos desconhecidos (renpy/defaultstore.py, _Config.
#     __setattr__). O lint passa, mas o jogo quebra em execucao.
#   - "default" colocaria a lista no store de jogo, e ela entraria
#     nos saves — um save antigo passaria a ditar quais historias
#     existem.
#   - Criada em "init", a lista entra no baseline do clean store
#     (o Ren'Py executa todo o init ANTES de clean_stores), logo
#     nao e serializada nos saves e e sempre reconstruida a partir
#     do script.
#
#  A prioridade de init (-50 aqui, -40 nos registros) vence a ordem
#  alfabetica dos arquivos, portanto registrar_historia ja existe
#  quando as historias se registram.
# ============================================================

init -50 python:

    historias_registradas = []

    def registrar_historia(id, titulo, label, subtitulo="", ordem=100):
        """
        Torna uma historia selecionavel na tela inicial.

        `id`         identificador curto e estavel (ex.: "historia1")
        `titulo`     nome exibido na tela de selecao
        `label`      label onde a historia comeca (ex.: "chapter1_start")
        `subtitulo`  linha de apoio, opcional
        `ordem`      menor aparece primeiro
        """

        historias_registradas.append({
            "id": id,
            "titulo": titulo,
            "label": label,
            "subtitulo": subtitulo,
            "ordem": ordem,
        })

    def historias_disponiveis():
        """Historias registradas, ordenadas, cujo label existe no script."""

        validas = [h for h in historias_registradas
                   if renpy.has_label(h["label"])]
        return sorted(validas, key=lambda h: (h["ordem"], h["titulo"]))
