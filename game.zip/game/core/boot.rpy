# ============================================================
#  boot.rpy — Infraestrutura de inicializacao (nucleo)
# ============================================================
#  Nao contem narrativa. Cuida de:
#   - estado compartilhado entre o nucleo e as historias
#   - o menu principal e o failsafe de inicializacao
#   - o roteamento para a historia a ser jogada
#
#  Narrativa, personagens e imagens de cada historia ficam em
#  game/stories/<historia>/.
# ============================================================

# --- Estado compartilhado (contratos nucleo <-> historia) ---

# True quando o jogador clicou em "Novo Jogo" no menu principal.
# Definido por screens.rpy (main_menu) e lido por "label start".
default entered_from_main_menu = False

# Suprime o botao de voltar no primeiro dialogo de uma historia.
# Lido por screens.rpy (screen say); escrito pela historia em curso.
default first_story_dialogue = False

# Label onde a historia escolhida comeca. Definido pela tela de
# selecao (screens_selecao.rpy) antes do Start(), ou pelo proprio
# "label start" quando o jogo e aberto sem passar pela selecao.
default historia_escolhida = None

# --- Imagens de interface ---
# Catedral + preto + uma leve camada de preto translucido por cima,
# para escurecer ainda mais a imagem original (ja bem escura) e
# garantir fundo preto em qualquer area nao coberta pela foto.
image main_menu_background = Composite(
    (1280, 720),
    (0, 0), "#000000",
    (0, 0), Transform(
        "images/menu_catedral.png",
        xysize=(1280, 720), fit="cover",
    ),
    (0, 0), "#00000040",
)


# Executado pelo Ren'Py antes de exibir o menu principal.
# Limpa a cena narrativa para o quarto nao permanecer atras do menu.
label before_main_menu:
    scene main_menu_background
    return


# Ponto de entrada usado pelo Ren'Py para exibir o menu inicial.
label main_menu_screen:
    call screen main_menu
    return


# Garante que saves antigos retomem o registro nativo de dialogos.
label after_load:
    $ _history = True
    return


# ============================================================
#  Inicio do jogo
# ============================================================
label start:

    # O contexto do menu principal desativa o historico. Ao iniciar uma
    # partida, reativa o registro nativo do Ren'Py em _history_list.
    $ _history = True

    if renpy.os.environ.get("HISTORY_DIAGNOSTIC"):
        call history_diagnostic
        return

    # Failsafe: se o jogo cair direto no start, abre um menu de seguranca.
    if not entered_from_main_menu:
        call startup_fallback_flow

    $ entered_from_main_menu = False

    # Sem historia escolhida (failsafe, save antigo ou entrada
    # direta no start): pergunta agora, dentro do jogo.
    if historia_escolhida is None:
        call escolher_historia

    jump expression historia_escolhida


# Pergunta qual historia jogar e guarda a escolha. Se o jogador
# voltar sem escolher, assume a primeira historia registrada.
label escolher_historia:
    call screen selecao_historia(em_jogo=True)

    if _return:
        $ historia_escolhida = _return
    else:
        $ historia_escolhida = historias_disponiveis()[0]["label"]

    return


label startup_fallback_flow:
    while True:
        call screen startup_fallback_menu

        if _return == "start":
            return
        elif _return == "load":
            call screen load
        elif _return == "preferences":
            call screen preferences
        elif _return == "quit":
            $ renpy.quit()
        else:
            return


# Acionado por HISTORY_DIAGNOSTIC=1. Popula o historico com entradas
# sinteticas e mantem a tela aberta para inspecao.
label history_diagnostic:
    $ n("Diagnostico 1", interact=False)
    $ p("Diagnostico 2", interact=False)
    $ b("Diagnostico 3", interact=False)
    $ p("Diagnostico 4", interact=False)
    $ n("Diagnostico 5", interact=False)
    $ _write_history_debug("HISTORY_DEBUG diagnostic count={} entries={!r}".format(len(_history_list), [(h.who, h.what) for h in _history_list]))
    show screen history
    $ renpy.pause(300.0, hard=True)
    return
