﻿## ============================================================
##  screens.rpy
## ============================================================

## ---- Tela de diálogo -------------------------------------
screen say(who, what):

    # Garante abertura do menu de pausa com Esc/clique direito.
    key "K_ESCAPE" action [FileTakeScreenshot(), ShowMenu("game_menu")]
    key "mouseup_3" action [FileTakeScreenshot(), ShowMenu("game_menu")]

    window:
        id "window"
        background Frame("#0d0d0ddd", 0, 0)
        xfill True
        yalign 1.0
        ysize 230
        padding (50, 24, 50, 24)

        vbox:
            spacing 8

            if who is not None:
                text who:
                    id "who"
                    color gui.accent_color
                    size 30
                    bold True

            text what:
                id "what"
                color "#eeeeee"
                size 27

    text "▼":
        xalign 0.985
        yalign 0.97
        size 20
        color gui.accent_color
        at indicator_bounce

    hbox:
        xalign 0.5
        yalign 0.985
        spacing 32

        textbutton "Voltar":
            action Rollback()
            sensitive not first_story_dialogue and renpy.can_rollback()
            style "dialog_action_button"

        textbutton "Salvar":
            action [FileTakeScreenshot(), ShowMenu("save")]
            style "dialog_action_button"

        textbutton "Carregar":
            action ShowMenu("load")
            style "dialog_action_button"

style dialog_action_button:
    background None
    hover_background None
    padding (4, 2)

style dialog_action_button_text:
    color "#ffffff"
    hover_color "#ff5a68"
    insensitive_color "#777777"
    size 19
    bold False
    outlines [(2, "#000000", 0, 0)]

transform indicator_bounce:
    yoffset 0
    linear 0.6 yoffset 6
    linear 0.6 yoffset 0
    repeat


## ---- Layout base com sidebar ─ usado por todas as telas -
## Estrutura:  [SIDEBAR 260px] | [DIVISOR 2px] | [CONTEÚDO]
screen side_layout(title="Menu", show_game_actions=True):

    add Transform("images/bg_quarto_wide.png", xysize=(1280, 720), fit="cover")
    add "#080812bb"

    hbox:
        xfill True
        yfill True

        ## ── SIDEBAR ──────────────────────────────────────
        frame:
            xsize 260
            yfill True
            background "#080810dd"
            padding (0, 30, 0, 20)

            vbox:
                xfill True
                spacing 4

                text title:
                    xalign 0.5
                    color gui.accent_color
                    size 34
                    bold True

                null height 20

                if show_game_actions:
                    textbutton "Histórico":
                        action ShowMenu("history")
                        style "sidebar_button"

                    textbutton "Salvar":
                        action ShowMenu("save")
                        style "sidebar_button"

                textbutton "Carregar":
                    action ShowMenu("load")
                    style "sidebar_button"

                textbutton "Opções":
                    action ShowMenu("preferences")
                    style "sidebar_button"

                if show_game_actions:
                    textbutton "Menu Princ.":
                        action MainMenu()
                        style "sidebar_button"

                null height 1

                textbutton "← Voltar":
                    action Return()
                    style "sidebar_return_button"

        ## ── DIVISOR ──────────────────────────────────────
        frame:
            xsize 2
            yfill True
            background "#c9323f66"

        ## ── CONTEÚDO ─────────────────────────────────────
        frame:
            xfill True
            yfill True
            background "#00000000"
            padding (30, 30)

            transclude

style sidebar_button:
    background "#00000000"
    hover_background "#c9323f22"
    xfill True
    padding (24, 13)

style sidebar_button_text:
    color "#999999"
    hover_color gui.accent_color
    size 25
    xalign 0.5

style sidebar_return_button:
    background "#00000000"
    hover_background "#c9323f22"
    padding (24, 13)

style sidebar_return_button_text:
    color "#c9323f"
    hover_color "#ffffff"
    size 25
    xalign 0.5


## ---- Menu principal --------------------------------------
screen main_menu():
    tag menu
    modal True

    fixed:
        area (0, 0, 1280, 720)

        add "main_menu_background":
            pos (0, 0)

        vbox:
            xalign 0.5
            yalign 0.42
            spacing 0

            text "Turno da Meia-Noite":
                xalign 0.5
                color gui.accent_color
                size 64
                bold True

            null height 60

            textbutton "Novo Jogo":
                xalign 0.5
                action ShowMenu("selecao_historia")
                style "main_button"

            textbutton "Carregar":
                xalign 0.5
                action ShowMenu("load")
                style "main_button"

            textbutton "Configurações":
                xalign 0.5
                action ShowMenu("preferences")
                style "main_button"

            textbutton "Sair":
                xalign 0.5
                action Quit(confirm=True)
                style "main_button"

        text "Laura Eder  •  Yasmin da Costa  •  Maria Rafaela  •  Milena":
            xalign 0.99
            yalign 0.99
            size 15
            color "#333333"

style main_button:
    background "#00000000"
    hover_background "#c9323f22"
    xminimum 300
    padding (30, 14)
    top_margin 4

style main_button_text:
    color "#cccccc"
    hover_color gui.accent_color
    size 30
    xalign 0.5


## ---- Fallback de inicialização ----------------------------
screen startup_fallback_menu():
    tag menu
    modal True

    add Transform("images/bg_quarto_wide.png", xysize=(1280, 720), fit="cover")
    add "#08081288"

    frame:
        xalign 0.5
        yalign 0.5
        xminimum 560
        background "#111111"
        padding (40, 34)

        vbox:
            spacing 14
            xfill True

            text "Turno da Meia-Noite":
                xalign 0.5
                color gui.accent_color
                size 52
                bold True

            null height 8

            textbutton "Novo Jogo":
                xalign 0.5
                action Return("start")
                style "main_button"

            textbutton "Carregar":
                xalign 0.5
                action Return("load")
                style "main_button"

            textbutton "Configurações":
                xalign 0.5
                action Return("preferences")
                style "main_button"

            textbutton "Sair":
                xalign 0.5
                action Return("quit")
                style "main_button"


## ---- Menu ao pressionar Esc -----------------------------
screen game_menu():
    tag menu
    modal True

    ## add Transform("images/bg_quarto_wide.png", xysize=(1280, 720), fit="cover")
    add "#08081288"

    frame:
        xalign 0.5
        yalign 0.5
        xminimum 460
        background "#111111"
        padding (0, 30)

        vbox:
            xfill True
            spacing 0

            ## Cabeçalho
            text "Pausado":
                xalign 0.5
                color gui.accent_color
                size 34
                bold True

            null height 24

            ## Linha divisória
            frame:
                xfill True
                ysize 1
                background "#c9323f44"

            null height 16

            textbutton "Salvar":
                xalign 0.5
                action ShowMenu("save")
                style "esc_button"

            textbutton "Carregar":
                xalign 0.5
                action ShowMenu("load")
                style "esc_button"

            textbutton "Configurações":
                xalign 0.5
                action ShowMenu("preferences")
                style "esc_button"

            ## Linha divisória
            null height 16
            frame:
                xfill True
                ysize 1
                background "#c9323f44"
            null height 16

            textbutton "Menu Principal":
                xalign 0.5
                action MainMenu()
                style "esc_button"

            textbutton "Sair do Jogo":
                xalign 0.5
                action Quit(confirm=True)
                style "esc_button"

            ## Linha divisória
            null height 16
            frame:
                xfill True
                ysize 1
                background "#c9323f44"
            null height 16

            textbutton "← Voltar":
                xalign 0.5
                action Return()
                style "esc_return_button"

style esc_button:
    background "#00000000"
    hover_background "#c9323f22"
    xminimum 400
    padding (20, 12)

style esc_button_text:
    color "#cccccc"
    hover_color gui.accent_color
    size 27
    xalign 0.5

style esc_return_button:
    background "#00000000"
    hover_background "#c9323f22"
    xminimum 400
    padding (20, 12)

style esc_return_button_text:
    color "#c9323f"
    hover_color "#ffffff"
    size 27
    xalign 0.5

style pause_button:
    background "#181818"
    hover_background "#c9323f33"
    xminimum 340
    padding (28, 14)

style pause_button_text:
    color "#cccccc"
    hover_color gui.accent_color
    size 27
    xalign 0.5


## ---- Menu de escolhas ------------------------------------
screen choice(items):

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 12

        for i in items:
            textbutton i.caption:
                action i.action
                style "choice_button"

    hbox:
        xalign 0.5
        yalign 0.985
        spacing 32

        textbutton "Voltar":
            action Rollback()
            sensitive renpy.can_rollback()
            style "dialog_action_button"

        textbutton "Salvar":
            action [FileTakeScreenshot(), ShowMenu("save")]
            style "dialog_action_button"

        textbutton "Carregar":
            action ShowMenu("load")
            style "dialog_action_button"

style choice_button:
    background Frame("#1a1a1acc", 8, 8)
    hover_background Frame("#c9323f55", 8, 8)
    xminimum 600
    padding (30, 16)

style choice_button_text:
    color "#eeeeee"
    hover_color "#ffffff"
    size 26
    xalign 0.5


## ---- Save / Load -----------------------------------------
screen save():
    tag menu
    use file_slots("Salvar", "save")

screen load():
    tag menu
    use file_slots("Carregar", "load")

screen file_slots(title, mode):

    default page_index = 1

    use side_layout(title, show_game_actions=not main_menu):

        vbox:
            xfill True
            spacing 12

            ## Paginação
            hbox:
                xalign 0.5
                spacing 6

                textbutton "<":
                    action SetScreenVariable("page_index", max(1, page_index - 1))
                    style "page_button"

                for pg in range(1, 10):
                    if pg == page_index:
                        textbutton "[pg]":
                            action SetScreenVariable("page_index", pg)
                            style "page_button_active"
                    else:
                        textbutton "[pg]":
                            action SetScreenVariable("page_index", pg)
                            style "page_button"

                textbutton ">":
                    action SetScreenVariable("page_index", min(9, page_index + 1))
                    style "page_button"

            ## Grade 3x2
            grid 3 2:
                xfill True
                spacing 8

                for i in range(6):
                    $ slot = i + 1
                    $ page = str(page_index)
                    button:
                        background "#1a1a1a"
                        hover_background "#2a1515"
                        xysize (300, 210)
                        padding (8, 8)
                        if mode == "load":
                            action FileLoad(slot, page=page)
                        else:
                            action FileSave(slot, page=page)

                        vbox:
                            xalign 0.5
                            yalign 0.5
                            spacing 4

                            fixed:
                                xysize (284, 160)
                                clipping True

                                add FileScreenshot(slot, page=page):
                                    xysize (284, 160)
                                    fit "cover"

                            text FileTime(slot, page=page, format="%d/%m/%Y %H:%M", empty="vazio"):
                                size 15
                                color "#777777"
                                xalign 0.5

                            text FileSaveName(slot, page=page):
                                size 16
                                color "#bbbbbb"
                                xalign 0.5

style page_button:
    background "#1a1a1a"
    hover_background "#c9323f44"
    padding (12, 7)
    xminimum 34

style page_button_text:
    color "#777777"
    hover_color "#ffffff"
    size 21
    xalign 0.5

style page_button_active:
    background "#c9323f44"
    padding (12, 7)
    xminimum 34

style page_button_active_text:
    color gui.accent_color
    size 21
    bold True
    xalign 0.5


## ---- Preferências ----------------------------------------
screen preferences():
    tag menu

    use side_layout("Opções", show_game_actions=not main_menu):

        vbox:
            xfill True
            spacing 28

            for lbl, pref in [
                ("Música",              "music volume"),
                ("Efeitos",             "sfx volume"),
                ("Velocidade do texto", "text speed"),
            ]:
                hbox:
                    spacing 16
                    ysize 50
                    text lbl:
                        color "#cccccc"
                        size 24
                        yalign 0.5
                        xminimum 220
                    bar:
                        value Preference(pref)
                        xsize 340
                        yalign 0.5


## ---- Histórico -------------------------------------------
screen history():
    tag menu
    predict False

    $ _write_history_debug("HISTORY_DEBUG screen count={}".format(len(_history_list)))

    use side_layout("Histórico", show_game_actions=not main_menu):



        side "c r":
            area (20, 70, 900, 550)

            viewport:
                id "history_viewport"
                mousewheel True
                draggable True
                pagekeys True
                yinitial 1.0

                vbox:
                    spacing 14
                    xsize 850

                    for h in _history_list:
                        $ speaker = h.who if h.who else ""
                        $ dialogue = renpy.filter_text_tags(h.what or "", allow={"alt", "noalt", "rt", "rb", "art"})

                        frame:
                            xsize 850
                            background "#11111144"
                            padding (18, 14)

                            hbox:
                                spacing 18
                                xsize 814

                                text speaker:
                                    color ((h.who_args or {}).get("color", gui.accent_color) if h.who else "#888888")
                                    size 21
                                    bold True
                                    xsize 170
                                    substitute False

                                text dialogue:
                                    color "#cccccc"
                                    size 21
                                    xmaximum 626
                                    substitute False

                    if not _history_list:
                        text "O histórico de diálogos está vazio.":
                            xalign 0.5
                            color "#888888"
                            size 22

            vbar:
                value YScrollValue("history_viewport")
                xsize 14


## ---- HUD mínimo ------------------------------------------
screen quick_menu():
    zorder 100

    # Atalho global de pausa durante gameplay.
    key "K_ESCAPE" action [FileTakeScreenshot(), ShowMenu("game_menu")]
    key "mouseup_3" action [FileTakeScreenshot(), ShowMenu("game_menu")]


## ---- Confirmação -----------------------------------------
screen confirm(message, yes_action, no_action):

    modal True
    add "#000000bb"

    frame:
        xalign 0.5
        yalign 0.5
        background "#181818"
        padding (50, 36)

        vbox:
            spacing 24
            xalign 0.5

            text message:
                color "#eeeeee"
                size 26
                xalign 0.5

            hbox:
                spacing 28
                xalign 0.5

                textbutton "Sim":
                    action yes_action
                    style "pause_button"

                textbutton "Não":
                    action no_action
                    style "pause_button"
