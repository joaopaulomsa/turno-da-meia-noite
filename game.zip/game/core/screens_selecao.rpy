# ============================================================
#  screens_selecao.rpy — Tela de selecao de historia
# ============================================================
#  Serve a dois caminhos:
#
#   - menu principal (em_jogo=False): o botao escolhe a historia
#     e inicia o jogo com Start(), como fazia o antigo "Novo Jogo".
#   - failsafe / entrada direta (em_jogo=True): chamada com
#     "call screen", devolve o label escolhido via Return().
# ============================================================

screen selecao_historia(em_jogo=False):
    tag menu
    modal True

    add "main_menu_background"
    add "#0d0d0dcc"

    vbox:
        xalign 0.5
        yalign 0.5
        spacing 10

        text "Escolha a história":
            xalign 0.5
            color gui.accent_color
            size 48
            bold True

        null height 24

        if not historias_disponiveis():
            text "Nenhuma história registrada.":
                xalign 0.5
                color gui.insensitive_color
                size 26

        for historia in historias_disponiveis():

            button:
                xsize 620
                padding (28, 18)
                background "#16161688"
                hover_background "#c9323f33"

                if em_jogo:
                    action Return(historia["label"])
                else:
                    action [
                        SetVariable("entered_from_main_menu", True),
                        SetVariable("historia_escolhida", historia["label"]),
                        Start(),
                    ]

                vbox:
                    spacing 4

                    text historia["titulo"]:
                        color "#eeeeee"
                        size 32

                    if historia["subtitulo"]:
                        text historia["subtitulo"]:
                            color "#999999"
                            size 22

        null height 20

        if em_jogo:
            textbutton "Voltar":
                xalign 0.5
                action Return(None)
                style "main_button"
        else:
            # Nao usar MainMenu(): get_sensitive() e
            # "not renpy.context()._main_menu", e esta tela e exibida
            # a partir do proprio menu principal — o botao ficaria
            # permanentemente insensivel.
            textbutton "Voltar":
                xalign 0.5
                action ShowMenu("main_menu")
                style "main_button"
