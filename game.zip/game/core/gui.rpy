## ============================================================
##  gui.rpy — Interface visual customizada
## ============================================================

## --- Paleta de cores ---
define gui.accent_color         = "#c9323f"    # vermelho (tema vampiro)
define gui.idle_color           = "#888888"
define gui.hover_color          = "#e85a68"
define gui.selected_color       = "#ffffff"
define gui.insensitive_color    = "#555555"
define gui.muted_color          = "#3a3a3a"
define gui.hover_muted_color    = "#4a2020"

## --- Fundo geral ---
define gui.background_color     = "#0d0d0d"
define gui.text_color           = "#eeeeee"
define gui.interface_text_color = "#d0d0d0"

## --- Fontes ---
define gui.text_font            = "DejaVuSans.ttf"
define gui.name_text_font       = "DejaVuSans.ttf"
define gui.interface_text_font  = "DejaVuSans.ttf"
define gui.text_size            = 28
define gui.name_text_size       = 30
define gui.interface_text_size  = 28

## --- Caixa de diálogo ---
define gui.textbox_height       = 220
define gui.textbox_yalign       = 1.0

## --- Nome do personagem ---
define gui.namebox_width        = 300
define gui.namebox_height       = None
define gui.namebox_borders      = Borders(5, 5, 5, 5)
define gui.namebox_tile         = False

## --- Botões de menu principal ---
define gui.main_menu_background = "#0d0d0d"
define gui.game_menu_background = "#0d0d0d"

## --- Barras (volume, etc.) ---
define gui.bar_size             = 36
define gui.scrollbar_size       = 14
define gui.slider_size          = 36

## --- Slots de save ---
define gui.slot_width           = 414
define gui.slot_height          = 309
define gui.slot_cols            = 3
define gui.slot_rows            = 2
